package bridge.solution.dao;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import com.fasterxml.jackson.databind.ObjectMapper;

import bridge.solution.domain.User;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(OrderAnnotation.class)
public class usercontrollertest {
	@Autowired
	private MockMvc mockMvc;
	User u1 = new User(111, "aaa", "bbb", "ab@email.com");

	@Test
	@Order(1)
	public void testCreateUser() throws Exception {
		this.mockMvc
				.perform(post("/User").content(asJsonString(u1)).contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.priority").value("Low"));
	}

	@Test
	@Order(2)
	public void testGetUserByID() throws Exception {
		this.mockMvc.perform(get("/User/111").accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(MockMvcResultMatchers.jsonPath("$.priority").value("Low"));
	}
	private static String asJsonString(final Object obj) {
		try {
		return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
		throw new RuntimeException(e);
		}
		}

}
