package bridge.solution.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import bridge.solution.dao.UserRepository;
import bridge.solution.domain.User;
import bridge.solution.service.UserService;

@RestController
public class UserController {
   @Autowired
   UserService service;
   @Autowired
   UserRepository repo;
   
   @PostMapping("/user")
	public ResponseEntity<User> createuser(@RequestBody User user) {
		service.saveuser(user);
		return new ResponseEntity<User>(user,HttpStatus.CREATED);
	}
   
   @GetMapping("/user/{userId}")
	public ResponseEntity<User> getUserDetails(@PathVariable Integer userId) {
	   if (repo.findById(userId).isPresent()) {
		return  ResponseEntity.status(HttpStatus.OK).body(repo.findById(userId).get());
	   }
	   else {
		   return new ResponseEntity("invalid userid", HttpStatus.UNAUTHORIZED);
	   }

	}
   
   @GetMapping("/user/sort")
   public List<User> sort()
   {
	   Sort sort=Sort.by("email");
	   return repo.findAll(sort);
   }
}
